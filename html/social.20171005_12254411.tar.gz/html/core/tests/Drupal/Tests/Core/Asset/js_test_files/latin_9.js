var latin9Char = '�';
